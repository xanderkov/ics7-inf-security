#include <iostream>
#include <random>
#include "Encoder.h"
#include "Enigma.h"
#define ALPHABET_NUM 26

int main() {
    uint8_t num_rotors = 3;

    // Reflectors
    int reflector_number = rand() % ALPHABET_NUM;

    std::vector<uint8_t> reflector;
    std::cout << "Reflector number: " << reflector_number << std::endl;
    for (int i = 0; i < ALPHABET_NUM; i++) {
        reflector.push_back((reflector_number + ALPHABET_NUM - i) % ALPHABET_NUM);
        std::cout << static_cast<int>(reflector[i]) << ", ";
    }
    std::cout << std::endl;
    // -----

    // Commutator
    int commutator_number = rand() % ALPHABET_NUM;

    std::vector<uint8_t> commutator;
    std::cout << "Commuator number: " << commutator_number << std::endl;
    for (int i = 0; i < ALPHABET_NUM; i++) {
        commutator.push_back((commutator_number + i) % ALPHABET_NUM);
        std::cout << static_cast<int>(commutator[i]) << ", ";
    }
    std::cout << std::endl;
    // -----

    // Rotors
    std::vector<std::vector<uint8_t>> rotors;
    for (int i = 0; i < num_rotors; i++) {
        int rotor_number = rand() % ALPHABET_NUM;
        std::cout << "Rotor number: " << rotor_number << std::endl;
        std::vector<uint8_t> rotor;
        for (int j = 0; j < ALPHABET_NUM; ++j) {
            rotor.push_back((rotor_number + j) % ALPHABET_NUM);
            std::cout << static_cast<int>(rotor[j]) << ", ";
        }
        rotors.push_back(rotor);
        std::cout << std::endl;
    }
    // --------------------

    // Setting up Enigma machine
    Enigma enigma(ALPHABET_NUM, num_rotors, reflector, rotors, commutator);

    // -------------------------

    // Setting up Encoder
    std::string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    Encoder encoder(alphabet.size(), alphabet);
    // ------------------------

    // Starting Enigma machine
    std::string message;
    std::cout << "Input string (without symbols that doesn't used in alphabet): ";
    std::cin >> message;

    std::vector<uint8_t> new_message;
    std::cout << "Encrypted message: ";
    for (auto &symbol: message) {
        try {
            uint8_t encoded_ch = encoder.encode(symbol);
            encoded_ch = enigma.encrypt(encoded_ch);
            uint8_t decoded_ch = encoder.decode(encoded_ch);
            new_message.push_back(decoded_ch);
            std::cout << decoded_ch;
        } catch (std::overflow_error &e) {
            std::cout << e.what() << std::endl;
        }

    }

    std::cout << std::endl;
    std::cout << "Decrypted message: ";
    // Check Enigma work
    Enigma enigma_two(ALPHABET_NUM, num_rotors, reflector, rotors, commutator);
    for (auto &symbol: new_message) {
        try {
            uint8_t encoded_ch = encoder.encode(symbol);
            encoded_ch = enigma_two.encrypt(encoded_ch);
            uint8_t decoded_ch = encoder.decode(encoded_ch);
            std::cout << decoded_ch;
        } catch (std::overflow_error &e) {
            std::cout << e.what() << std::endl;
        }

    }
    return 0;
}